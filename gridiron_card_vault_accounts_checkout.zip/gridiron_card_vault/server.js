const express = require("express");
const Stripe = require("stripe");
const bcrypt = require("bcryptjs");
const session = require("express-session");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 4242;

if (!process.env.STRIPE_SECRET_KEY) {
  console.error("Missing STRIPE_SECRET_KEY. Copy .env.example to .env and add your Stripe test secret key.");
  process.exit(1);
}
const stripe = Stripe(process.env.STRIPE_SECRET_KEY);

// Prices are controlled on the server, never trusted from the browser.
const PRODUCTS = {
  1: { name: "Patrick Mahomes — 2023 Prizm", amount: 8999 },
  2: { name: "Josh Allen — 2024 Select", amount: 3450 },
  3: { name: "Lamar Jackson — 2023 Donruss", amount: 2800 },
  4: { name: "Justin Jefferson — 2024 Score", amount: 1499 },
  5: { name: "C.J. Stroud — 2023 Rookie", amount: 7400 },
  6: { name: "Saquon Barkley — 2024 Mosaic", amount: 1250 },
  7: { name: "Jordan Love — 2024 Base", amount: 499 },
  8: { name: "Caleb Williams — 2024 Base", amount: 650 }
};

app.use(express.static(path.join(__dirname, "public")));
app.use(express.json());
app.use(session({
  secret: process.env.SESSION_SECRET || "replace-this-with-a-long-random-secret-before-deploying",
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", maxAge: 7 * 24 * 60 * 60 * 1000 }
}));

// Demo in-memory users only. Use a persistent database and a production session store before launch.
const usersByEmail = new Map();

app.post("/auth/email", async (req, res) => {
  try {
    const { mode, name = "", email, password } = req.body || {};
    if (!email || typeof email !== "string" || !/^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/.test(email)) {
      return res.status(400).json({ error: "Enter a valid email address." });
    }
    if (typeof password !== "string" || password.length < 8) {
      return res.status(400).json({ error: "Password must be at least 8 characters." });
    }
    const normalizedEmail = email.trim().toLowerCase();
    if (mode === "signup") {
      if (usersByEmail.has(normalizedEmail)) return res.status(409).json({ error: "An account with this email already exists." });
      const passwordHash = await bcrypt.hash(password, 12);
      usersByEmail.set(normalizedEmail, { name: String(name).slice(0, 100), email: normalizedEmail, passwordHash });
    } else if (mode === "signin") {
      const user = usersByEmail.get(normalizedEmail);
      if (!user || !(await bcrypt.compare(password, user.passwordHash))) {
        return res.status(401).json({ error: "Email or password is incorrect." });
      }
    } else {
      return res.status(400).json({ error: "Choose sign in or create account." });
    }
    req.session.userEmail = normalizedEmail;
    return res.json({ user: { email: normalizedEmail } });
  } catch (error) {
    console.error("Auth error:", error.message);
    return res.status(500).json({ error: "Could not process your account request." });
  }
});

app.post("/auth/signout", (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});

app.get("/auth/google", (_req, res) => res.status(501).send("Google OAuth is not configured yet."));
app.get("/auth/apple", (_req, res) => res.status(501).send("Apple OAuth is not configured yet."));


app.post("/create-checkout-session", async (req, res) => {
  try {
    const items = req.body && req.body.items;
    if (!Array.isArray(items) || items.length === 0 || items.length > 30) {
      return res.status(400).json({ error: "Your cart is empty or invalid." });
    }

    const line_items = [];
    for (const item of items) {
      const id = Number(item.id);
      const quantity = Number(item.quantity);
      const product = PRODUCTS[id];
      if (!product || !Number.isInteger(quantity) || quantity < 1 || quantity > 20) {
        return res.status(400).json({ error: "A card or quantity in your cart is invalid." });
      }
      line_items.push({
        quantity,
        price_data: {
          currency: "usd",
          unit_amount: product.amount,
          product_data: { name: product.name }
        }
      });
    }

    const origin = `${req.protocol}://${req.get("host")}`;
    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      payment_method_types: ["card"],
      line_items,
      success_url: `${origin}/?payment=success`,
      cancel_url: `${origin}/?payment=cancelled`
    });
    return res.json({ url: session.url });
  } catch (error) {
    console.error("Stripe checkout error:", error.message);
    return res.status(500).json({ error: "Secure checkout could not be created. Please try again later." });
  }
});

app.get("/health", (_req, res) => res.json({ ok: true }));
app.listen(PORT, () => console.log(`Gridiron Card Vault listening on port ${PORT}`));
