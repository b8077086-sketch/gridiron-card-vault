# Gridiron Card Vault — Stripe Checkout setup

This package adds a server-side Stripe Checkout endpoint. It is **not live or ready to take real money until you configure Stripe and deploy the Node server**.

## What this does
- The cart sends only card IDs and quantities to the server.
- The server decides the prices (not the browser) and creates a Stripe-hosted checkout session.
- Customers enter payment details on Stripe's secure checkout page, not on this site.
- The included product list and prices are sample listings. Seller-created cards in the browser demo are not purchasable through this endpoint yet.

## Run locally in Stripe test mode
1. Create/sign in to a Stripe account at https://dashboard.stripe.com/.
2. In Stripe Dashboard, use **test mode** and copy your test secret key (`sk_test_...`).
3. Copy `.env.example` to `.env`, then put the test secret key after `STRIPE_SECRET_KEY=`.
4. Install Node.js 18 or newer.
5. In this folder, run `npm install` then `npm start`.
6. Open http://localhost:4242.

Never put your Stripe secret key in `index.html`, a public repository, or any client-side JavaScript. Keep `.env` private.

## Before accepting real payments
- Test successful, cancelled, and failed payments in Stripe test mode first.
- Replace sample product names/prices with the real inventory and create a shared database for listings and orders.
- Add Stripe webhooks to verify payment completion before marking an order paid or shipping anything.
- Add seller accounts, authentication, inventory/stock control, shipping, tax, refund and customer-support policies as needed.
- Switch to live Stripe keys only after your Stripe account is eligible and your site is ready.
- Deploy the Node server and the `public/` site together on a Node-capable host; a static-only host/drop page cannot run `server.js`.

This starter does not collect shipping addresses or persist orders yet, and does not include a webhook. Do not treat a redirect to the success page alone as proof of payment.


## Sign up / login scaffold
- The site now includes a sign-in/create-account dialog with email/password, Google and Apple buttons.
- Email/password endpoints hash passwords with bcrypt and create a server session, but the included user store is in-memory only. Accounts disappear when the server restarts and won't work reliably across multiple server instances.
- Google and Apple buttons are UI only until OAuth credentials and a proper auth provider are configured.
- Before public use, replace the in-memory user map with a persistent database, add email verification and password reset, CSRF/rate limiting, secure production session storage, and configure Google/Apple OAuth redirect URLs. Use a long random `SESSION_SECRET`.
- Do not use this scaffold as a production authentication system yet.
